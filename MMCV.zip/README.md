# Muslim Marriage CV Maker

A premium, privacy-first single-page web application for creating respectful and professional marriage biodata PDFs.

## Features

- **Multi-section Form**: Organized into Basic info, Religious details, Education, Profession, Family, Personal, and Preferences.
- **Real-time Progress Tracker**: Sticky completion bar that updates as you fill required fields.
- **Live Document Preview**: Instant, document-style preview that updates as you type.
- **Client-side PDF Generation**: Generates high-quality A4 PDFs entirely in the browser using `html2pdf.js`.
- **Privacy First**: No database, no backend. All data stays in your browser's memory and is never sent to any server.
- **Bilingual Support**: Labels and helper text provided in both English and Bengali.
- **Premium Aesthetics**: Calm, ivory/emerald/gold theme with Islamic-inspired geometric patterns.
- **Sample Data**: One-click "Fill Sample Data" to see a complete profile instantly.
- **Mobile Friendly**: Responsive layout with a dedicated mobile preview modal.

## Tech Stack

- **React + TypeScript**
- **Vite** (Build Tool)
- **Tailwind CSS** (Styling)
- **Framer Motion** (Animations)
- **Lucide React** (Icons)
- **React Hook Form + Zod** (Form management & Validation)
- **html2pdf.js** (PDF Export)
- **Canvas Confetti** (Celebration effects)

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn

### Installation

1. Clone the repository or download the source code.
2. Navigate to the project directory:
   ```bash
   cd MMCV
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Open your browser and navigate to `http://localhost:3000`.

## Privacy Policy

This application is designed with privacy as the top priority. 
- **Zero Data Retention**: We do not store any information you enter.
- **Client-Side Only**: All processing (form handling, PDF generation) happens locally on your device.
- **No Analytics**: No tracking or cookies are used to monitor your activity.

## License

This project is open-source and intended for helping the Ummah.
